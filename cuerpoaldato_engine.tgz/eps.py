def bd(**k): return k
def P(e,x,y,z=110,m='bob',**k): d=dict(e=e,x=x,y=y,z=z,m=m);d.update(k);return d
def bars(*rows,top=900): return {"type":"bars","top":top,"rows":[dict(l=l,v=v,v0=v0,c=c,fmt=f) for l,v0,v,c,f in rows]}
def stat(c,cap,to=None,suf="",txt=None,top=860):
    d={"type":"stat","c":c,"cap":cap,"top":top,"suf":suf,"dec":0}
    if txt:d["txt"]=txt
    else:d["to"]=to
    return d
def stamp(claim,verdict,c="red"): return {"type":"stamp","claim":claim,"verdict":verdict,"c":c,"at":1.3}
def lst(*it): return {"type":"list","top":690,"items":list(it)}
def cta(text): return {"type":"cta","text":text,"btn":"@cuerpoaldato"}
def beat(head,hc,mood,brain,props,mod): return {"head":head,"hc":hc,"mood":mood,"brain":brain,"props":props,"mod":mod}
def happy(**k): d={"eye":1,"bags":0,"curve":.9,"tint":0,"sweat":0,"mo":0,"drool":0,"brow":0,"lx":0,"ly":0,"aL":125,"aR":55,"nod":0,"rot":0,"s":1,"y":560};d.update(k);return d
EPS={}
EPS['ep31']=dict(pill="¿No bebes agua? Mira esto.",lines="""Pasas el día sin beber agua y dices que no tienes sed. Tu cuerpo ya está avisando.
Con perder solo un dos por ciento del agua de tu cuerpo, tu concentración empieza a caer.
Aparecen el dolor de cabeza, el cansancio y el mal humor.
Y la sed llega tarde: cuando la sientes, ya vas con déficit.
Tu orina es la señal más fácil: amarillo oscuro significa que te falta agua.
Pero no se arregla tomando un litro de golpe. Tu cuerpo lo elimina.
Qué puedes hacer: bebe un poco durante todo el día y lleva una botella contigo.
Un vaso al despertar, uno con cada comida, y agua antes de tener sed.
Mándaselo a quien toma café todo el día y casi nada de agua, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Pasas el día sin *beber agua*","amber",.3,happy(eye:=.7,curve=-.3,sweat=1) if False else happy(eye=.7,curve=-.3,sweat=1,lx=0,ly=.2),[P("🌵",150,470,120,'wob'),P("☀️",575,430,120,'pulse')],bars(("Agua",100,60,"amber","{v}%"))),
 beat("Pierdes *2 %* y tu *concentración* cae","red",.5,happy(eye=.5,bags=.5,curve=-.4,nod=1,aL=105,aR=75),[P("💫",360,400,90,'orbit',rx=150,ry=36),P("💫",360,400,70,'orbit',rx=150,ry=36,ph=3.1)],bars(("Concentración",100,70,"red","{v}%"))),
 beat("Dolor de cabeza y *mal humor*","red",.6,happy(eye=.55,bags=.4,curve=-.5,brow=.7,aL=120,aR=60),[P("🤕",570,470,110,'wob'),P("⚡",170,480,90,'fly')],bars(("Dolor de cabeza ↑",20,80,"red","{v}%"),("Energía ↓",80,30,"amber","{v}%"),top=880)),
 beat("La *sed* llega tarde","amber",.65,happy(eye=.8,curve=-.2,sweat=1,mo=.3),[P("⏳",560,480,120,'wob'),P("👅",170,700,80,'bob')],stamp("Bebo cuando tengo sed","LA SED LLEGA TARDE")),
 beat("Tu *orina* te avisa","amber",.55,happy(eye=1,curve=.2,ly=.6,lx=-.6),[P("🚽",160,700,130,'pulse'),P("🟡",570,470,70,'bob')],bars(("Orina",15,85,"amber","OSCURA"),("Hidratación",70,25,"red","BAJA"),top=880)),
 beat("*Un litro* de golpe no sirve","violet",.4,happy(eye=.9,curve=-.1,mo=.4),[P("🫗",560,470,110,'wob'),P("🚽",170,700,100,'wob')],stat("violet","tu cuerpo lo elimina<br>y no te hidrata mejor",txt="1 L DE GOLPE")),
 beat("Bebe *poco a poco*","green",.05,happy(curve=.9,wave=300),[P("💧",170,470,100,'rise',ph=.1),P("🚰",575,470,110,'bob')],bars(("Agua",60,100,"green","{v}%"),top=900)),
 beat("Tres hábitos *simples*","green",0,happy(s=.62,y=470,wave=300),[P("💧",140,430,110,'pulse'),P("🥤",590,430,110,'wob')],lst("Un vaso al despertar","Uno con cada comida","Botella contigo todo el día")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien toma casi nada de <span style='color:#5aa8ff'>agua</span>"))])
EPS['ep32']=dict(pill="¿Comes rápido? Mira esto.",lines="""Terminas de comer en cinco minutos y aún tienes hambre. No es tu estómago, es tu velocidad.
Tu cerebro tarda unos veinte minutos en recibir la señal de que ya estás lleno.
Si comes rápido, sigues comiendo antes de que llegue esa señal.
Eso se asocia con comer más, aumentar de peso y sentir más hinchazón.
Además, si no masticas bien, tu estómago trabaja más y puedes tragar aire.
Y no, tomar mucha agua para empujar la comida no lo soluciona.
Qué puedes hacer: deja los cubiertos entre bocado y bocado.
Mastica con calma, apaga la pantalla y apunta a comer en veinte minutos.
Mándaselo a quien come como si lo persiguieran, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Comes en *5 minutos*… y sigues con hambre","amber",.3,happy(eye=1,curve=.3,mo=.5,drool=1,lx=-.8,ly=.6),[P("🍔",150,690,150,'pulse'),P("⏱️",575,450,110,'wob')],bars(("Tiempo comiendo",100,25,"amber","5 min"))),
 beat("Tu cerebro tarda *20 minutos*","violet",.4,happy(eye=.8,curve=.1,ly=.3),[P("📨",570,470,110,'bob'),P("⏳",160,470,110,'wob')],stat("violet","en saber que ya estás lleno",to=20,suf=" min")),
 beat("Sigues comiendo *sin señal*","red",.6,happy(eye=1,curve=.2,mo=.6,drool=0,lx=-.5,ly=.5,brow=.3),[P("🍝",150,700,130,'wob'),P("🍕",580,700,120,'wob'),P("🍔",560,470,90,'bob')],bars(("Comida",20,95,"red","{v}%"),("Señal de lleno",10,15,"amber","TARDE"),top=880)),
 beat("Más *peso* y más *hinchazón*","red",.7,happy(eye=.7,curve=-.4,tint=.2,sweat=1),[P("🎈",160,490,120,'wob'),P("⚖️",570,700,110,'bob')],bars(("Hinchazón ↑",20,80,"red","{v}%"),("Peso ↑",15,60,"amber","{v}%"),top=880)),
 beat("Tragas *aire*","amber",.55,happy(eye=.8,curve=-.2,mo=.4),[P("💨",160,480,100,'rise',ph=.1),P("💨",580,520,90,'rise',ph=.6)],bars(("Esfuerzo del estómago",40,100,"amber","×2"))),
 beat("Beber *agua* no lo arregla","red",.5,happy(eye=.8,curve=-.1),[P("🥤",575,480,120,'wob')],stamp("Agua para empujar la comida","NO LO SOLUCIONA")),
 beat("Deja los *cubiertos*","green",.05,happy(curve=.9,wave=300),[P("🍴",170,480,110,'bob'),P("😋",575,480,100,'pulse')],bars(("Saciedad",20,90,"green","{v}%"))),
 beat("Tres hábitos *simples*","green",0,happy(s=.62,y=470,wave=300),[P("🍽️",140,430,110,'pulse'),P("📵",590,430,110,'wob')],lst("Cubiertos abajo entre bocados","Mastica con calma","Sin pantallas al comer")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien come como si lo <span style='color:#ffb84d'>persiguieran</span>"))])
EPS['ep33']=dict(pill="¿Te aguantas el baño? Mira esto.",lines="""Te aguantas las ganas de ir al baño porque estás ocupado. Tu vejiga lo nota.
Tu vejiga puede estirarse bastante, pero no está hecha para aguantar horas todos los días.
Si lo haces seguido, puede aumentar el riesgo de infecciones urinarias.
Aguantar muy seguido también puede debilitar los músculos que controlan la vejiga.
Y ojo: tomar poca agua para ir menos al baño empeora el problema.
Aguantar de vez en cuando no te daña. El problema es hacerlo costumbre.
Qué puedes hacer: ve cuando sientas la primera señal clara.
Si te arde al orinar o tienes fiebre, consulta a un médico.
Mándaselo a quien se aguanta todo el turno, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Te *aguantas* el baño","amber",.3,happy(eye=.8,curve=-.4,sweat=1,aL=130,aR=50),[P("🚽",160,480,120,'wob'),P("⏰",575,450,110,'wob')],bars(("Vejiga",30,90,"amber","{v}%"))),
 beat("No está hecha para *horas*","red",.5,happy(eye=.7,curve=-.5,sweat=1,brow=.5),[P("🎈",575,480,130,'pulse'),P("⏳",160,470,110,'wob')],bars(("Vejiga",90,100,"red","LLENA"))),
 beat("Más riesgo de *infección*","red",.65,happy(eye=.6,tint=.5,curve=-.5,sweat=1,brow=.5),[P("🦠",170,520,100,'fly',at=.3),P("🦠",580,500,90,'fly',at=.6),P("🦠",200,740,80,'fly',at=.9)],stat("red","si lo haces muy seguido",txt="INFECCIÓN")),
 beat("Músculos *más débiles*","amber",.6,happy(eye=.6,bags=.3,curve=-.4),[P("💪",170,500,120,'wob'),P("📉",575,480,100,'bob')],bars(("Músculos de la vejiga",90,50,"amber","{v}%"),top=900)),
 beat("Tomar *menos agua* empeora","red",.7,happy(eye=.7,curve=-.3,sweat=1),[P("🥤",575,480,120,'wob'),P("🚫",575,480,140,'pulse')],stamp("Bebo menos para ir menos","EMPEORA TODO")),
 beat("*A veces* no daña","green",.2,happy(curve=.5,eye=1),[P("🙂",170,480,100,'bob'),P("🔁",575,480,100,'wob')],stat("amber","el problema es la costumbre",txt="A VECES")),
 beat("Ve con la *primera señal*","green",.05,happy(curve=.9,wave=300),[P("🚻",170,480,120,'bob'),P("😌",575,480,100,'pulse')],bars(("Alivio",10,100,"green","{v}%"))),
 beat("Tres *reglas*","green",0,happy(s=.62,y=470,wave=300),[P("🚻",140,430,110,'pulse'),P("🩺",590,430,110,'wob')],lst("Ve con la primera señal","Bebe agua durante el día","Si arde o hay fiebre: médico")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien se aguanta <span style='color:#ffb84d'>todo el turno</span>"))])
EPS['ep34']=dict(pill="¿Te lavas poco las manos? Mira esto.",lines="""Tocas el celular, el transporte y el dinero, y luego comes sin lavarte las manos.
Muchas infecciones, como resfríos y diarreas, se pasan por las manos.
Lavarte con agua y jabón por veinte segundos reduce el riesgo de enfermarte.
Solo mojarte las manos casi no sirve. El jabón es el que arrastra los gérmenes.
Los momentos clave son antes de comer, después del baño y al llegar a casa.
El gel alcohol ayuda cuando no hay agua, pero el jabón es mejor si tienes las manos sucias.
Qué puedes hacer: frota las palmas, el dorso, entre los dedos y las uñas.
Cuenta hasta veinte, enjuaga y sécate con una toalla limpia.
Mándaselo a quien dice que las manos se lavan solas, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Comes *sin lavarte* las manos","red",.5,happy(eye=.9,curve=-.2,tint=.3,sweat=1),[P("📱",160,480,110,'wob'),P("🦠",575,480,100,'fly'),P("🦠",200,740,90,'fly',at=.4)],bars(("Gérmenes en tus manos",20,90,"red","ALTOS"))),
 beat("Tus manos pasan *resfríos*","red",.6,happy(eye=.6,tint=.6,curve=-.5,sweat=1,brow=.5),[P("🤧",170,500,110,'wob'),P("🦠",575,470,100,'fly',at=.3),P("🦠",570,730,80,'fly',at=.6)],stat("red","y también diarreas",txt="MANOS")),
 beat("*20 segundos* te protegen","green",.1,happy(curve=.9,wave=300),[P("🧼",170,480,120,'pulse'),P("🚰",575,480,110,'bob'),P("🫧",200,720,80,'rise',ph=.2)],stat("green","con agua y jabón reducen<br>el riesgo de enfermarte",to=20,suf=" s")),
 beat("Sin *jabón* casi no sirve","amber",.5,happy(eye=.8,curve=-.2),[P("💧",575,480,110,'wob')],stamp("Mojarme las manos basta","SIN JABÓN CASI NO SIRVE")),
 beat("Tres momentos *clave*","green",.1,happy(s=.62,y=470,wave=300),[P("🍽️",140,430,110,'pulse'),P("🚽",590,430,110,'wob')],lst("Antes de comer","Después del baño","Al llegar a casa")),
 beat("Jabón *gana* al gel","violet",.3,happy(curve=.7,eye=1),[P("🧴",170,480,120,'bob'),P("🧼",575,480,120,'pulse')],bars(("Gel alcohol",20,60,"amber","AYUDA"),("Agua y jabón",20,100,"green","MEJOR"),top=880)),
 beat("Frota *todo*","green",.05,happy(curve=.9,eye=1,aL=70,aR=110),[P("🫧",160,480,100,'rise',ph=.1),P("🫧",580,470,80,'rise',ph=.5),P("🧼",360,790,130,'wob')],bars(("Gérmenes",90,10,"green","{v}%"))),
 beat("Tres *pasos*","green",0,happy(s=.62,y=470,wave=300),[P("🧼",140,430,110,'pulse'),P("🧻",590,430,110,'wob')],lst("Palmas, dorso y entre los dedos","Uñas y pulgares","Cuenta 20 y sécate bien")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien dice que las manos <span style='color:#5aa8ff'>se lavan solas</span>"))])
EPS['ep35']=dict(pill="¿Se te eriza la piel? Mira esto.",lines="""Te llega un escalofrío y se te eriza la piel. Eso viene de tus ancestros.
Bajo cada vello hay un músculo diminuto. Cuando se contrae, tira del vello hacia arriba.
Se activa con el frío, el miedo y también con la emoción, como una canción que te encanta.
En animales con pelaje, el vello erizado atrapa aire caliente y los hace verse más grandes.
En los humanos casi no tenemos pelo, y el reflejo quedó como un resto de esa herencia.
No lo controlas: lo decide tu sistema nervioso, sin pedirte permiso.
Y no es una señal de que algo ande mal. Es un reflejo normal.
Si te pasa con música, tu cerebro está reaccionando con mucha emoción.
Mándaselo a quien se emociona con una canción, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Se te *eriza* la piel","violet",.3,happy(eye=1,curve=.2,sweat=0,aL=110,aR=70),[P("🥶",160,480,110,'wob'),P("⚡",575,470,100,'fly')],bars(("Piel de gallina",10,90,"violet","{v}%"))),
 beat("Un *músculo* diminuto tira del vello","blue",.3,happy(eye=1,curve=.3,ly=.4),[P("💪",170,490,110,'wob'),P("🔬",575,480,110,'bob')],stat("blue","bajo cada vello",txt="MÚSCULO")),
 beat("Frío, miedo y *emoción*","violet",.4,happy(eye=1,curve=.6,aL=110,aR=70),[P("❄️",160,480,100,'wob'),P("😱",575,480,100,'pulse'),P("🎵",360,420,90,'rise',ph=.2)],bars(("Frío",20,80,"blue","{v}%"),("Miedo",20,70,"red","{v}%"),("Emoción",20,90,"violet","{v}%"),top=880)),
 beat("Antes servía para *abrigar*","amber",.3,happy(eye=1,curve=.4),[P("🐈",170,490,120,'bob'),P("🐺",575,490,120,'wob')],bars(("Aire atrapado",10,90,"amber","{v}%"),("Tamaño aparente",30,90,"amber","↑"),top=880)),
 beat("Hoy es un *resto* de esa herencia","amber",.2,happy(eye=1,curve=.2),[P("🧬",170,490,110,'orbit',rx=40,ry=20),P("🦴",575,490,110,'wob')],stat("amber","herencia de tus ancestros",txt="HERENCIA")),
 beat("Lo decide tu *sistema nervioso*","blue",.3,happy(eye=1,curve=.3,lx=.5,ly=-.3),[P("🧠",575,480,100,'pulse'),P("🚫",170,490,100,'wob')],stamp("Lo controlo yo","NO DEPENDE DE TI")),
 beat("Es un *reflejo normal*","green",.1,happy(curve=.9),[P("✅",170,490,110,'pulse'),P("🙂",575,480,100,'bob')],bars(("Reflejo normal",10,100,"green","SANO"))),
 beat("Con música: *emoción* pura","violet",.2,happy(curve=1,eye=1,wave=300),[P("🎧",170,490,120,'bob'),P("🎶",575,470,110,'rise',ph=.1),P("🎶",360,420,90,'rise',ph=.5)],lst("Tu cerebro reacciona","Te emociona de verdad","Piel de gallina incluida")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien se emociona con una <span style='color:#a78bfa'>canción</span>"))])
EPS['ep36']=dict(pill="¿Te da hipo? Mira esto.",lines="""Estás tan tranquilo y de repente: hip. El hipo te pilla desprevenido.
Tu diafragma se contrae de golpe, sin que tú lo ordenes.
Justo después, las cuerdas vocales se cierran, y ese cierre brusco hace el sonido.
Suele aparecer si comes muy rápido, tomas bebidas con gas o te ríes mucho.
También el alcohol o un cambio brusco de temperatura pueden provocarlo.
Normalmente se va solo en pocos minutos.
Qué puedes hacer: aguanta la respiración unos segundos, o toma pequeños sorbos de agua fría.
Si dura más de cuarenta y ocho horas, consulta a un médico.
Mándaselo a quien le da hipo en el peor momento, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Te da *hipo* sin avisar","amber",.3,happy(eye=1,curve=.2,mo=.4,nod=1),[P("😮",170,490,110,'wob'),P("💥",575,480,100,'fly')],bars(("Hip",10,90,"amber","¡HIP!"))),
 beat("Tu *diafragma* se contrae de golpe","blue",.35,happy(eye=1,curve=.2,nod=1),[P("🫁",170,490,120,'pulse'),P("⚡",575,480,100,'fly')],stat("blue","sin que tú lo ordenes",txt="DIAFRAGMA")),
 beat("Las *cuerdas vocales* se cierran","violet",.35,happy(eye=1,curve=.1,mo=.6),[P("🗣️",170,490,110,'wob'),P("🔊",575,480,110,'pulse')],bars(("Contracción",10,100,"blue","{v}%"),("Cierre de cuerdas",10,90,"violet","{v}%"),top=880)),
 beat("Comer *rápido*, gas y risa","amber",.4,happy(eye=1,curve=.5,mo=.4),[P("🥤",160,490,110,'wob'),P("🍔",575,490,110,'bob'),P("😂",360,430,90,'orbit',rx=120,ry=30)],lst("Comer muy rápido","Bebidas con gas","Reírte mucho")),
 beat("Alcohol o *cambios* de temperatura","amber",.4,happy(eye=.9,curve=.1),[P("🍺",170,490,110,'wob'),P("🌡️",575,490,110,'pulse')],bars(("Probabilidad de hipo",20,75,"amber","{v}%"))),
 beat("Se va *solo* en minutos","green",.15,happy(curve=.8,eye=1),[P("⏱️",170,490,110,'wob'),P("😌",575,480,100,'bob')],stat("green","normalmente se va solo",to=5,suf=" min")),
 beat("Aguanta la *respiración*","green",.1,happy(curve=.7,eye=1,wave=300),[P("🧊",170,490,110,'bob'),P("💧",575,480,100,'rise',ph=.1)],lst("Aguanta la respiración unos segundos","Sorbos pequeños de agua fría","Respira con calma")),
 beat("Más de *48 horas*: médico","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("📅",575,490,110,'wob')],stamp("Dura más de 48 horas","CONSULTA A UN MÉDICO")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien le da <span style='color:#ffb84d'>hipo</span> en el peor momento"))])
EPS['ep37']=dict(pill="¿Tu cuerpo brilla? Mira esto.",lines="""Tu cuerpo brilla ahora mismo, y tus ojos no lo pueden ver.
Se llama emisión ultradébil de fotones: partículas de luz que tus células emiten en cantidades diminutas.
Viene de reacciones químicas normales dentro de tus células, como las que usan oxígeno.
Es una luz muchísimo más débil de lo que tu ojo puede detectar.
Se ha medido con cámaras ultrasensibles, en oscuridad total.
Y no, no es un aura ni algo místico: es química.
Las plantas y los animales también lo hacen.
Eso sí, es tan tenue que no sirve para iluminar nada.
Mándaselo a quien ama los datos raros, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Tu cuerpo *brilla* ahora mismo","teal",.4,happy(eye=1,curve=.7,tint=.3),[P("✨",160,470,110,'pulse'),P("✨",580,440,90,'pulse',ph=1.2),P("🌟",360,360,80,'bob')],bars(("Luz que emites",5,60,"teal","TENUE"))),
 beat("*Fotones* en cantidades diminutas","teal",.4,happy(eye=1,curve=.5),[P("💡",170,490,110,'bob'),P("🔬",575,480,110,'wob')],stat("teal","tus células emiten luz",txt="FOTONES")),
 beat("Viene de *química* normal","blue",.3,happy(eye=1,curve=.4),[P("⚗️",170,490,110,'wob'),P("🫁",575,490,110,'pulse')],bars(("Reacciones con oxígeno",20,80,"blue","{v}%"))),
 beat("Mucho *más débil* que tu vista","amber",.3,happy(eye=.8,curve=.1,lx=.5),[P("👁️",170,490,120,'wob'),P("🚫",575,490,110,'pulse')],bars(("Lo que ves",90,90,"amber","VISIBLE"),("Tu brillo",5,5,"teal","INVISIBLE"),top=880)),
 beat("Medido con *cámaras* especiales","violet",.3,happy(eye=1,curve=.4),[P("📷",170,490,120,'bob'),P("🌑",575,490,110,'pulse')],stat("violet","en oscuridad total",txt="CÁMARAS")),
 beat("No es un *aura*: es química","green",.15,happy(curve=.6,eye=1),[P("🔮",170,490,110,'wob'),P("🧪",575,490,110,'bob')],stamp("Es un aura mística","ES SOLO QUÍMICA")),
 beat("También *plantas* y animales","green",.1,happy(curve=.8,eye=1,wave=300),[P("🌱",170,490,110,'bob'),P("🐾",575,490,110,'wob')],lst("Personas","Plantas","Animales")),
 beat("Muy *tenue* para iluminar","amber",.2,happy(curve=.2,eye=1),[P("🔦",170,490,110,'wob'),P("🌙",575,490,100,'bob')],bars(("Luz útil",5,5,"amber","CERO"))),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien ama los <span style='color:#2dd4bf'>datos raros</span>"))])
EPS['ep38']=dict(pill="¿Bostezaste? Mira esto.",lines="""Lees esto y quizá ya estás a punto de bostezar. Te lo advertí.
El bostezo se contagia, incluso con solo ver a otra persona o pensar en ello.
Aún no se sabe del todo por qué bostezamos, y eso es lo curioso.
Una idea es que ayuda a enfriar el cerebro, pero no está confirmado.
No es solo por sueño: también aparece con aburrimiento o cuando cambias de actividad.
Solemos contagiarnos más con personas cercanas.
Y no, bostezar no significa que te falte oxígeno. Eso es un mito.
Si bostezas mucho sin motivo, revisa cuánto estás durmiendo.
Mándaselo a quien ya bostezó leyendo esto, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Ya vas a *bostezar*","amber",.3,happy(eye=.6,mo=1,curve=.2,nod=1),[P("🥱",170,490,120,'pulse'),P("😴",575,490,110,'wob')],bars(("Ganas de bostezar",10,90,"amber","{v}%"))),
 beat("El bostezo se *contagia*","violet",.35,happy(eye=.7,mo=.8,curve=.2),[P("🥱",170,490,110,'wob'),P("🥱",575,490,110,'wob',ph=1),P("🥱",360,420,80,'bob')],stat("violet","con solo verlo o pensarlo",txt="CONTAGIA")),
 beat("Nadie sabe *bien* por qué","blue",.3,happy(eye=1,curve=.1,ly=-.4,lx=.3),[P("❓",170,490,120,'wob'),P("❓",575,470,100,'bob',ph=1)],stamp("Sabemos por qué bostezamos","AÚN ES UN MISTERIO")),
 beat("Quizá *enfría* el cerebro","teal",.25,happy(eye=1,curve=.4,tint=.2),[P("🧊",170,490,110,'bob'),P("🌡️",575,490,110,'pulse')],bars(("Temperatura cerebral",70,40,"teal","↓"),top=900)),
 beat("Sueño, aburrimiento y *cambios*","amber",.35,happy(eye=.6,bags=.3,curve=0),[P("😴",170,490,110,'wob'),P("⏰",575,490,110,'bob')],lst("Sueño","Aburrimiento","Cambiar de actividad")),
 beat("Más con *personas cercanas*","violet",.3,happy(eye=1,curve=.7),[P("👫",170,490,120,'bob'),P("💞",575,470,100,'rise',ph=.2)],bars(("Cercanos",20,90,"violet","{v}%"),("Desconocidos",20,40,"amber","{v}%"),top=880)),
 beat("*Mito*: no es falta de oxígeno","red",.3,happy(eye=1,curve=.1),[P("🫁",170,490,110,'wob'),P("🚫",575,490,110,'pulse')],stamp("Bostezo = falta de oxígeno","ES UN MITO")),
 beat("Bostezas mucho: revisa tu *sueño*","green",.1,happy(s=.62,y=470,wave=300,curve=.8),[P("🛏️",140,430,110,'pulse'),P("🌙",590,430,110,'wob')],lst("Duerme 7 horas","Misma hora cada noche","Menos pantallas de noche")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien ya <span style='color:#ffb84d'>bostezó</span> leyendo esto"))])
EPS['ep39']=dict(pill="¿Se te duerme la pierna? Mira esto.",lines="""Te sientas con las piernas cruzadas y se te duerme el pie. Y duele al moverlo.
Al presionar un nervio, este deja de mandar bien las señales.
Por eso sientes el pie adormecido, como si no fuera tuyo.
Cuando quitas la presión, el nervio se reactiva de golpe y aparece el hormigueo.
Ese hormigueo molesto es solo el nervio despertando.
No daña nada si pasa de vez en cuando y se va rápido.
Qué puedes hacer: cambia de postura y mueve el pie con calma.
Si pasa seguido, sin causa clara, o no se va, consulta a un médico.
Mándaselo a quien se sienta con las piernas cruzadas, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Se te *duerme* el pie","amber",.3,happy(eye=.9,curve=-.2,sweat=1),[P("🦶",170,490,120,'wob'),P("💤",575,470,100,'rise',ph=.1)],bars(("Sensibilidad del pie",90,20,"amber","{v}%"))),
 beat("Un *nervio* queda presionado","red",.45,happy(eye=.8,curve=-.2,brow=.3),[P("🪑",170,490,110,'bob'),P("⚡",575,480,100,'fly')],stat("red","y deja de mandar señales",txt="NERVIO")),
 beat("Se siente como si *no fuera tuyo*","violet",.4,happy(eye=.9,curve=-.1,lx=.5,ly=.5),[P("🦶",170,490,110,'wob'),P("❔",575,480,100,'bob')],bars(("Señal al cerebro",80,15,"violet","{v}%"),top=900)),
 beat("Al soltar: *hormigueo*","amber",.5,happy(eye=.7,curve=-.4,sweat=1,brow=.4),[P("✨",170,490,100,'fly'),P("✨",575,470,90,'fly',ph=1),P("🦶",360,430,100,'wob')],bars(("Señal",15,100,"amber","{v}%"),("Hormigueo",10,90,"red","¡AY!"),top=880)),
 beat("Es el nervio *despertando*","green",.2,happy(curve=.6,eye=1),[P("⏰",170,490,110,'wob'),P("🙂",575,480,100,'bob')],stat("green","el nervio vuelve a funcionar",txt="DESPERTANDO")),
 beat("De vez en cuando *no daña*","green",.1,happy(curve=.8,eye=1),[P("✅",170,490,110,'pulse'),P("⏱️",575,490,100,'wob')],bars(("Daño",10,5,"green","NINGUNO"))),
 beat("Cambia de *postura*","green",.05,happy(curve=.9,wave=300),[P("🧘",170,490,120,'bob'),P("🦶",575,490,110,'wob')],lst("Cambia de postura","Mueve el pie con calma","No cruces piernas por horas")),
 beat("Si pasa *seguido*: médico","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("📅",575,490,110,'wob')],stamp("Pasa seguido y sin causa","CONSULTA A UN MÉDICO")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien se sienta con las <span style='color:#5aa8ff'>piernas cruzadas</span>"))])
EPS['ep40']=dict(pill="¿Saltarte el desayuno adelgaza? Mira esto.",lines="""Dicen que saltarte el desayuno te hace bajar de peso. ¿Será verdad?
Lo que de verdad cuenta es cuánto comes en total durante el día.
Si te saltas el desayuno y luego comes de más, el ahorro se pierde.
Algunas personas llegan con tanta hambre que eligen peor.
Para otras, desayunar o no desayunar da casi lo mismo.
Si te sirve esto, suscríbete, que vienen más mitos explicados.
Lo importante es la calidad: proteína, fruta, fibra, y menos azúcar.
Escucha a tu cuerpo, y si tienes diabetes, consulta a tu médico.
Mándaselo a quien dice que no desayuna para bajar de peso, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("¿Saltarte el desayuno *adelgaza*?","amber",.3,happy(eye=1,curve=.2,ly=-.3),[P("🍳",170,490,120,'wob'),P("⚖️",575,490,110,'bob')],bars(("Peso que bajas",10,40,"amber","¿?"))),
 beat("Importa lo que comes *en total*","blue",.3,happy(eye=1,curve=.4),[P("🍽️",170,490,110,'bob'),P("📊",575,490,110,'pulse')],stat("blue","lo que cuenta es el día completo",txt="EL TOTAL")),
 beat("Luego comes *de más*","red",.4,happy(eye=.9,curve=.3,mo=.5),[P("🍔",170,490,110,'wob'),P("🍟",575,490,110,'bob')],bars(("Ahorro de calorías",70,10,"red","{v}%"))),
 beat("Llegas con *mucha hambre*","amber",.35,happy(eye=.8,curve=-.2),[P("😩",170,490,110,'wob'),P("🍕",575,490,110,'bob')],lst("Eliges peor","Comes más rápido","Más antojos")),
 beat("Para otros da *casi lo mismo*","green",.15,happy(curve=.6,eye=1),[P("🤷",170,490,110,'bob'),P("🙂",575,480,100,'wob')],stamp("Desayunar es obligatorio","DEPENDE DE LA PERSONA")),
 beat("*Suscríbete* para más mitos","violet",.3,happy(s=.75,y=450,wave=300,curve=.8),[P("🔔",170,490,120,'wob'),P("▶️",575,490,110,'pulse')],stat("violet","vienen más mitos explicados",txt="SUSCRÍBETE")),
 beat("Importa la *calidad*","green",.1,happy(curve=.8,eye=1),[P("🥚",170,490,110,'bob'),P("🍎",575,490,110,'wob')],lst("Proteína","Fruta y fibra","Menos azúcar")),
 beat("Con diabetes: *médico*","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("📅",575,490,110,'wob')],stamp("Tienes diabetes y cambias comidas","CONSULTA A TU MÉDICO")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien <span style='color:#ffb84d'>se salta el desayuno</span> para bajar de peso"))])
EPS['ep41']=dict(pill="¿Sudar más quema más grasa? Mira esto.",lines="""¿Sudar mucho significa que quemaste más grasa? Spoiler: no.
El sudor es la forma en que tu cuerpo se enfría.
Lo que pierdes al sudar es sobre todo agua, no grasa.
Y esa agua la recuperas en cuanto vuelves a beber.
Hay gente que suda poco y entrena durísimo, y también quema calorías.
Si te gusta este tipo de datos, suscríbete.
Lo que quema calorías es el esfuerzo, no cuánto sudes.
Eso sí, con calor o ejercicio intenso, toma agua para reponer lo que sudaste.
Mándaselo a quien se pone ropa extra para sudar más, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("¿Sudar más *quema* más grasa?","amber",.4,happy(eye=1,curve=.2,sweat=1),[P("💦",170,490,120,'wob'),P("🔥",575,490,110,'pulse')],bars(("Grasa quemada",20,40,"amber","¿?"))),
 beat("Sudar es *enfriarte*","blue",.4,happy(eye=1,curve=.4,tint=.2,sweat=1),[P("🌡️",170,490,110,'pulse'),P("💧",575,480,100,'rise',ph=.1)],stat("blue","tu cuerpo se enfría",txt="TERMOSTATO")),
 beat("Pierdes *agua*, no grasa","teal",.3,happy(eye=1,curve=.3),[P("🚰",170,490,110,'bob'),P("🏋️",575,490,110,'wob')],bars(("Lo que sale",90,90,"teal","AGUA"),("Grasa",10,10,"amber","POCA"),top=880)),
 beat("La *recuperas* al beber","green",.15,happy(curve=.7,eye=1),[P("🥤",170,490,110,'bob'),P("⚖️",575,490,110,'wob')],bars(("Peso tras beber",60,95,"green","VUELVE"))),
 beat("Sudar poco *también* quema","violet",.15,happy(curve=.6,eye=1),[P("🏃",170,490,120,'wob'),P("👍",575,490,100,'bob')],stamp("Sudas poco = no entrenas","SÍ QUEMAS CALORÍAS")),
 beat("*Suscríbete* para más datos","violet",.3,happy(s=.75,y=450,wave=300,curve=.8),[P("🔔",170,490,120,'wob'),P("▶️",575,490,110,'pulse')],stat("violet","más datos de tu cuerpo",txt="SUSCRÍBETE")),
 beat("Cuenta el *esfuerzo*","green",.1,happy(curve=.8,eye=1),[P("💪",170,490,120,'bob'),P("⏱️",575,490,110,'wob')],lst("Intensidad","Constancia","Descanso")),
 beat("Con calor, *toma agua*","blue",.2,happy(curve=.6,eye=1,wave=300),[P("☀️",170,490,110,'pulse'),P("💧",575,490,110,'bob')],lst("Bebe antes","Bebe durante","Bebe después")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien <span style='color:#5aa8ff'>entrena con ropa extra</span> para sudar más"))])
EPS['ep42']=dict(pill="¿Un huevo al día es malo? Mira esto.",lines="""¿Comer un huevo al día es malo para tu corazón? Mucha gente lo cree.
Los huevos tienen proteína y varios nutrientes importantes.
Contienen colesterol, pero en la mayoría de las personas el colesterol de la comida pesa menos que las grasas saturadas.
Para una persona sana, un huevo al día suele encajar en una dieta equilibrada.
Importa más cómo lo preparas: hervido o a la plancha mejor que frito con mucha grasa.
Si te gusta aprender esto, suscríbete.
Y mira con qué lo acompañas: tocino y mantequilla cambian la historia.
Si tienes colesterol alto, diabetes o problemas del corazón, pregunta a tu médico.
Mándaselo a quien come huevo todos los días, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("¿Un huevo al día es *malo*?","amber",.3,happy(eye=1,curve=.2,ly=-.3),[P("🥚",170,490,120,'wob'),P("❤️",575,490,110,'pulse')],bars(("Riesgo para el corazón",30,50,"amber","¿?"))),
 beat("Tiene *proteína* y nutrientes","green",.15,happy(curve=.7,eye=1),[P("🍳",170,490,110,'bob'),P("💪",575,490,110,'wob')],lst("Proteína","Vitaminas","Minerales")),
 beat("Trae *colesterol*, pero...","amber",.3,happy(eye=1,curve=.1),[P("🧈",170,490,110,'wob'),P("🥓",575,490,110,'bob')],bars(("Pesa más",20,85,"red","GRASA SATURADA"),("Colesterol del huevo",20,35,"amber","MENOS"),top=880)),
 beat("Para gente *sana* suele encajar","green",.15,happy(curve=.7,eye=1),[P("✅",170,490,110,'pulse'),P("🥗",575,490,110,'bob')],stat("green","en una dieta equilibrada",to=1,suf=" al día")),
 beat("Importa *cómo* lo preparas","blue",.2,happy(eye=1,curve=.5),[P("♨️",170,490,110,'wob'),P("🍳",575,490,110,'bob')],bars(("Hervido o plancha",20,90,"green","MEJOR"),("Frito con mucha grasa",20,40,"red","PEOR"),top=880)),
 beat("*Suscríbete* para más datos","violet",.3,happy(s=.75,y=450,wave=300,curve=.8),[P("🔔",170,490,120,'wob'),P("▶️",575,490,110,'pulse')],stat("violet","vienen más mitos explicados",txt="SUSCRÍBETE")),
 beat("Mira el *acompañamiento*","amber",.3,happy(eye=1,curve=.1),[P("🥓",170,490,110,'wob'),P("🧈",575,490,110,'bob')],lst("Tocino","Mantequilla","Mucha sal")),
 beat("Colesterol alto: *médico*","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("📅",575,490,110,'wob')],stamp("Tienes colesterol alto o diabetes","CONSULTA A TU MÉDICO")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien come <span style='color:#ffb84d'>huevo todos los días</span>"))])
EPS['ep43']=dict(pill="¿Leer con poca luz daña la vista? Mira esto.",lines="""¿Leer con poca luz te daña la vista para siempre? Es un mito muy repetido.
Leer con poca luz cansa los ojos, pero el daño no es permanente.
Con poca luz tus ojos se esfuerzan más y parpadeas menos.
Por eso aparecen ojos secos, ardor y dolor de cabeza.
Esa molestia pasa al descansar.
Si te gustó, suscríbete para más mitos.
Lo mejor es leer con buena luz y hacer pausas.
Si ves borroso seguido o te duelen mucho los ojos, consulta a un oftalmólogo.
Mándaselo a quien lee en la cama a oscuras, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("¿Leer con poca luz *daña*?","amber",.3,happy(eye=1,curve=.2,ly=-.3),[P("📖",170,490,120,'wob'),P("🕯️",575,490,110,'pulse')],bars(("Daño permanente",30,10,"amber","¿?"))),
 beat("Cansa, pero *no daña* para siempre","green",.15,happy(curve=.6,eye=1),[P("😌",170,490,110,'bob'),P("👁️",575,490,110,'wob')],stamp("Leer a oscuras daña tus ojos","DAÑO NO PERMANENTE")),
 beat("Los ojos *se esfuerzan*","amber",.4,happy(eye=.7,curve=-.1,sweat=1),[P("👁️",170,490,120,'wob'),P("🔍",575,490,110,'bob')],bars(("Esfuerzo del ojo",30,90,"amber","{v}%"))),
 beat("Parpadeas *menos*","blue",.4,happy(eye=.5,curve=-.1),[P("😑",170,490,110,'wob'),P("💧",575,480,100,'rise',ph=.1)],bars(("Parpadeos",80,30,"blue","{v}%"))),
 beat("Ardor y *dolor de cabeza*","red",.35,happy(eye=.7,curve=-.3,brow=.4),[P("🤕",170,490,110,'wob'),P("🔥",575,490,100,'pulse')],lst("Ojos secos","Ardor","Dolor de cabeza")),
 beat("*Suscríbete* para más mitos","violet",.3,happy(s=.75,y=450,wave=300,curve=.8),[P("🔔",170,490,120,'wob'),P("▶️",575,490,110,'pulse')],stat("violet","vienen más mitos explicados",txt="SUSCRÍBETE")),
 beat("Buena *luz* y pausas","green",.1,happy(curve=.8,eye=1,wave=300),[P("💡",170,490,110,'pulse'),P("⏱️",575,490,110,'wob')],lst("Buena luz","Pausa cada 20 minutos","Parpadea más")),
 beat("Ves borroso seguido: *oftalmólogo*","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("👓",575,490,110,'wob')],stamp("Visión borrosa que no pasa","CONSULTA A UN OFTALMÓLOGO")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien <span style='color:#ffb84d'>lee a oscuras</span> en la cama"))])
EPS['ep44']=dict(pill="¿Enjuague bucal reemplaza el cepillado? Mira esto.",lines="""¿Un enjuague bucal puede reemplazar el cepillado? Respuesta corta: no.
El cepillado remueve la placa, esa capa de bacterias pegada a tus dientes.
El enjuague da frescura y puede ayudar, pero no limpia igual.
Por eso es un complemento, no un reemplazo.
Lo ideal es cepillarte dos veces al día con pasta con flúor.
Si esto te sirve, suscríbete.
Y no olvides el hilo dental, que llega donde el cepillo no.
Si te sangran las encías seguido, consulta a tu dentista.
Mándaselo a quien se enjuaga en vez de cepillarse, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("¿Enjuague *reemplaza* al cepillo?","amber",.3,happy(eye=1,curve=.2,ly=-.3),[P("🪥",170,490,120,'wob'),P("🧴",575,490,110,'bob')],bars(("¿Reemplazo?",30,15,"amber","¿?"))),
 beat("*No*: son cosas distintas","red",.3,happy(eye=1,curve=.1),[P("🚫",170,490,110,'pulse'),P("🪥",575,490,110,'wob')],stamp("El enjuague reemplaza al cepillo","NO LO REEMPLAZA")),
 beat("El cepillo quita la *placa*","green",.15,happy(curve=.7,eye=1),[P("🦷",170,490,120,'bob'),P("🫧",575,480,100,'rise',ph=.1)],bars(("Placa removida con cepillo",20,90,"green","{v}%"))),
 beat("El enjuague da *frescura*","blue",.2,happy(curve=.6,eye=1,tint=.2),[P("🌿",170,490,110,'bob'),P("😁",575,480,100,'wob')],bars(("Limpieza mecánica",10,25,"blue","MENOS"),top=900)),
 beat("Es un *complemento*","green",.1,happy(curve=.7,eye=1),[P("➕",170,490,110,'pulse'),P("🪥",575,490,110,'wob')],stat("green","ayuda, pero no sustituye",txt="EXTRA")),
 beat("*Suscríbete* para más datos","violet",.3,happy(s=.75,y=450,wave=300,curve=.8),[P("🔔",170,490,120,'wob'),P("▶️",575,490,110,'pulse')],stat("violet","más datos de tu cuerpo",txt="SUSCRÍBETE")),
 beat("Dos veces al día, con *flúor*","green",.1,happy(curve=.8,eye=1,wave=300),[P("🪥",170,490,110,'bob'),P("🦷",575,490,110,'wob')],lst("Cepíllate 2 veces al día","Pasta con flúor","Usa hilo dental")),
 beat("Encías que sangran: *dentista*","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("📅",575,490,110,'wob')],stamp("Te sangran las encías seguido","CONSULTA A TU DENTISTA")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien <span style='color:#2dd4bf'>se enjuaga en vez de cepillarse</span>"))])
EPS['ep45']=dict(pill="¿Tus remedios se dañan con el calor? Mira esto.",lines="""Llega el verano, y tus remedios pueden estar en el peor lugar de la casa.
El calor y la humedad pueden hacer que algunos medicamentos pierdan efecto.
Dejarlos en el auto o junto a la ventana al sol es un error común.
El baño tampoco es buena idea, por la humedad.
Mejor guárdalos en un lugar fresco, seco y lejos de la luz.
Si te sirve esto, suscríbete.
Revisa la caja: algunos remedios piden refrigeración, así que lee la etiqueta.
Y si cambió el color, el olor o la textura, pregunta al farmacéutico.
Mándaselo a quien guarda los remedios en el auto, y sígueme para más datos de tu cuerpo.""",beats=[
 beat("Tus remedios en *verano*","amber",.35,happy(eye=1,curve=.1,sweat=1),[P("💊",170,490,120,'wob'),P("☀️",575,490,110,'pulse')],bars(("Temperatura de la casa",30,85,"amber","{v}°"))),
 beat("Calor y humedad *restan efecto*","red",.4,happy(eye=.9,curve=.1,brow=.3),[P("🌡️",170,490,110,'pulse'),P("💧",575,480,100,'rise',ph=.1)],bars(("Efecto del remedio",90,50,"red","{v}%"))),
 beat("Error común: *el auto*","red",.4,happy(eye=1,curve=-.1,brow=.3),[P("🚗",170,490,110,'wob'),P("🪟",575,490,110,'bob')],stamp("Dejarlos en el auto es seguro","MALA IDEA")),
 beat("El *baño* tampoco","amber",.3,happy(eye=1,curve=0),[P("🚿",170,490,110,'wob'),P("💦",575,480,100,'rise',ph=.1)],stat("amber","por la humedad",txt="BAÑO NO")),
 beat("Lugar *fresco y seco*","green",.1,happy(curve=.8,eye=1,wave=300),[P("🗄️",170,490,110,'bob'),P("✅",575,490,110,'pulse')],lst("Fresco","Seco","Lejos de la luz")),
 beat("*Suscríbete* para más datos","violet",.3,happy(s=.75,y=450,wave=300,curve=.8),[P("🔔",170,490,120,'wob'),P("▶️",575,490,110,'pulse')],stat("violet","más datos de tu cuerpo",txt="SUSCRÍBETE")),
 beat("Lee la *etiqueta*","blue",.2,happy(eye=1,curve=.5),[P("🏷️",170,490,110,'bob'),P("🧊",575,490,110,'wob')],stat("blue","algunos piden refrigeración",txt="ETIQUETA")),
 beat("Cambió algo: *farmacia*","red",.3,happy(eye=1,curve=.1,brow=.3),[P("🩺",170,490,120,'bob'),P("💊",575,490,110,'wob')],stamp("Cambió color, olor o textura","PREGUNTA AL FARMACÉUTICO")),
 beat("","blue",0,happy(s=.8,y=430,wave=300),[P("❤️",200,380,80,'rise',ph=.1),P("❤️",530,400,60,'rise',ph=.5)],cta("Mándaselo a quien guarda los remedios <span style='color:#ffb84d'>en el auto</span>"))])
