import numpy as np,subprocess,os,scipy.io.wavfile as w
from scipy.signal import butter,lfilter
SR=44100
def lp(x,f,o=2):b,a=butter(o,f/(SR/2));return lfilter(b,a,x)
def hp(x,f,o=2):b,a=butter(o,f/(SR/2),'high');return lfilter(b,a,x)
def env(n,a,r):
    e=np.ones(n);na=int(a*SR);nr=int(r*SR)
    e[:na]=np.linspace(0,1,na)**2;e[-nr:]=np.minimum(e[-nr:],np.linspace(1,0,nr)**2);return e
def whoosh(d=.45,up=True,vol=.5):
    n=int(d*SR);t=np.linspace(0,1,n);x=np.random.RandomState(1).randn(n)
    out=np.zeros(n);
    for i in range(0,n,2048):
        seg=x[i:i+2048];fc=300+ (2800 if up else 2800)*(t[min(i,n-1)] if up else 1-t[min(i,n-1)])
        b,a=butter(2,[max(80,fc*.6)/(SR/2),min(.99,fc*1.4/(SR/2))],'band');out[i:i+2048]=lfilter(b,a,seg)
    e=np.sin(np.pi*t)**1.6;return out/np.max(np.abs(out))*e*vol
def pop(vol=.4,f=620):
    n=int(.16*SR);t=np.arange(n)/SR;x=np.sin(2*np.pi*(f+f*1.4*np.exp(-t*40))*t)*np.exp(-t*28);return x*vol
def ping(f=1046,vol=.28):
    n=int(.7*SR);t=np.arange(n)/SR;x=(np.sin(2*np.pi*f*t)+.4*np.sin(2*np.pi*f*2.01*t)+.2*np.sin(2*np.pi*f*3.02*t))*np.exp(-t*7);return x*vol
def impact(vol=.9):
    n=int(.9*SR);t=np.arange(n)/SR;x=np.sin(2*np.pi*(55+90*np.exp(-t*18))*t)*np.exp(-t*5.5)
    nz=lp(np.random.RandomState(3).randn(n),2500)*np.exp(-t*14)*.5;return (x+nz)*vol
def tick(vol=.18):
    n=int(.03*SR);t=np.arange(n)/SR;return np.sin(2*np.pi*1800*t)*np.exp(-t*160)*vol
def riser(d=1.2,vol=.3):
    n=int(d*SR);t=np.linspace(0,1,n);x=np.random.RandomState(5).randn(n);y=np.zeros(n)
    for i in range(0,n,2048):
        fc=400+4000*t[min(i,n-1)]**2;b,a=butter(2,[fc*.7/(SR/2),min(.99,fc*1.3/(SR/2))],'band');y[i:i+2048]=lfilter(b,a,x[i:i+2048])
    return y/np.max(np.abs(y))*t**2*vol
def music(dur,seed=7,bpm=84):
    n=int(dur*SR);t=np.arange(n)/SR;rs=np.random.RandomState(seed)
    chords=[[57,60,64],[53,57,60],[48,52,55],[55,59,62]]  # Am F C G
    beat=60/bpm;bar=beat*4;out=np.zeros(n)
    for k in range(int(dur/bar)+1):
        ch=chords[k%4];s=int(k*bar*SR);e=min(n,int((k+1)*bar*SR));m=e-s
        if m<=0:break
        tt=np.arange(m)/SR;pad=np.zeros(m)
        for nt in ch:
            f=440*2**((nt-69)/12)
            for dt in(-.6,0,.6):pad+=np.sin(2*np.pi*(f+dt)*tt)+.3*np.sin(2*np.pi*2*(f+dt)*tt)
        pad*=np.minimum(1,np.minimum(tt/.5,(bar-tt)/.6))*0.045
        bass=np.sin(2*np.pi*(440*2**((ch[0]-12-69)/12))*tt)*np.minimum(1,np.minimum(tt/.2,(bar-tt)/.3))*.16
        out[s:e]+=pad+bass
    # soft pulse hats + plucks
    for k in range(int(dur/beat)+1):
        s=int((k*beat+beat/2)*SR)
        if s+2000<n:
            hs=hp(rs.randn(2000),6000)*np.exp(-np.arange(2000)/SR*90)*.05;out[s:s+2000]+=hs
        if k%2==0:
            ch=chords[(k//4)%4];nt=ch[(k//2)%3]+12;f=440*2**((nt-69)/12);m=int(.5*SR)
            if int(k*beat*SR)+m<n:
                tt=np.arange(m)/SR;out[int(k*beat*SR):int(k*beat*SR)+m]+=np.sin(2*np.pi*f*tt)*np.exp(-tt*6)*.035
    kk=lp(out,3500);return kk
def place(buf,x,t):
    s=int(t*SR);e=min(len(buf),s+len(x))
    if s<len(buf):buf[s:e]+=x[:e-s]
def build(ep,vfiles,out_wav,workdir):
    dur=ep['dur'];n=int((dur+0.3)*SR);voice=np.zeros(n)
    for b,vf in zip(ep['beats'],vfiles):
        raw=os.path.join(workdir,'v.wav');subprocess.run(['ffmpeg','-v','error','-y','-i',vf,'-ar',str(SR),'-ac','1',raw],check=True)
        sr,x=w.read(raw);x=x.astype(float)/32768;place(voice,x,b['t0']+.05)
    w.write(os.path.join(workdir,'voice_raw.wav'),SR,(np.clip(voice,-1,1)*32767).astype(np.int16))
    subprocess.run(['ffmpeg','-v','error','-y','-i',os.path.join(workdir,'voice_raw.wav'),'-af','highpass=f=75,equalizer=f=180:t=q:w=1.2:g=2.2,equalizer=f=3400:t=q:w=1.0:g=2.5,acompressor=threshold=-21dB:ratio=3.2:attack=6:release=120:makeup=5,alimiter=limit=0.89','-ar',str(SR),os.path.join(workdir,'voice.wav')],check=True)
    sr,v=w.read(os.path.join(workdir,'voice.wav'));voice=v.astype(float)/32768
    voice=np.pad(voice,(0,max(0,n-len(voice))))[:n]
    sfx=np.zeros(n)
    for b in ep['beats']:
        t0=b['t0'];i=b['i'] if 'i' in b else 0
        place(sfx,whoosh(.42,True,.38),t0-.02)
        md=b.get('mod');r=b.get('ring')
        if r:place(sfx,pop(.35,520),t0+.55)
        if md:
            ty=md['type']
            if ty=='stat':
                for k in range(14):place(sfx,tick(.16),t0+.4+k*.075)
                place(sfx,pop(.45,380),t0+1.55)
            if ty=='bars':
                for j,_ in enumerate(md['rows']):place(sfx,pop(.38,500+j*120),t0+.5+j*.35)
            if ty=='stamp':place(sfx,impact(.85),t0+md.get('at',1.2))
            if ty=='list':
                for j,_ in enumerate(md['items']):place(sfx,ping(880+j*140,.3),t0+.95+j*.9)
            if ty=='cta':place(sfx,ping(1318,.3),t0+.8);place(sfx,riser(.8,.0),t0)
    m=music(dur+.3)
    # sidechain-like ducking from voice envelope
    ev=np.abs(voice);ev=lp(ev,6,1);ev=ev/ (ev.max()+1e-9);duck=1-0.62*np.clip(ev*3.2,0,1)
    m=m*duck
    fin=m*0.55+sfx*0.55
    # fade in/out music
    fin[:int(.4*SR)]*=np.linspace(0,1,int(.4*SR));
    fin[-int(1.2*SR):]*=np.linspace(1,0,int(1.2*SR))
    mix=voice*1.0+fin
    w.write(os.path.join(workdir,'mix.wav'),SR,(np.clip(mix,-1,1)*32767).astype(np.int16))
    subprocess.run(['ffmpeg','-v','error','-y','-i',os.path.join(workdir,'mix.wav'),'-af','loudnorm=I=-14:TP=-1.5:LRA=7','-ar',str(SR),out_wav],check=True)
