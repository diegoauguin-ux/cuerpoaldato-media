import json,sys,subprocess,os,base64
from playwright.sync_api import sync_playwright
def build(ep,durs,lead=0.55,gap=0.28,tail=1.1):
    t=lead
    for b,d in zip(ep['beats'],durs):
        b['t0']=t-0.05; b['t1']=t+d+gap; t+=d+gap
    ep['dur']=t+tail; ep['beats'][-1]['t1']=ep['dur']
    return ep
def render(ep,out,logo,fps=30,only=None,scale=1):
    html=open(os.path.join(os.path.dirname(__file__),'template.html')).read()
    lg='data:image/png;base64,'+base64.b64encode(open(logo,'rb').read()).decode()
    html=html.replace('LOGO',lg).replace('__EP__',json.dumps(ep))
    p='/tmp/_ep.html';open(p,'w').write(html)
    with sync_playwright() as pw:
        br=pw.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox','--disable-gpu','--font-render-hinting=none'])
        pg=br.new_page(viewport={'width':720,'height':1280})
        pg.goto('file://'+p); pg.wait_for_timeout(400)
        if only is not None:
            for i,t in enumerate(only):
                pg.evaluate('t=>setT(t)',t); pg.screenshot(path=f'{out}_{i}.png')
            br.close(); return
        n=int(ep['dur']*fps)
        ff=subprocess.Popen(['ffmpeg','-v','error','-y','-f','image2pipe','-framerate',str(fps),'-c:v','mjpeg','-i','-','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',out],stdin=subprocess.PIPE)
        for i in range(n):
            pg.evaluate('t=>setT(t)',i/fps)
            ff.stdin.write(pg.screenshot(type='jpeg',quality=93))
        ff.stdin.close(); ff.wait(); br.close()
