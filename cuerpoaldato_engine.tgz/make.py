import sys,os,subprocess,importlib;sys.path.insert(0,'/home/claude/v2/engine');sys.path.insert(0,'/home/claude/v2')
import render,audio
name=sys.argv[1]
if name in __import__('eps').EPS:
    d0=__import__('eps').EPS[name];ep={'pill':d0['pill'],'beats':d0['beats']}
else:
    mod=importlib.import_module(name);ep=mod.EP
vd=f'/home/claude/v2/{name}'
vf=sorted(f'{vd}/{f}' for f in os.listdir(vd) if f.endswith('.mp3'))
d=[float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f]))-0.05 for f in vf]
render.build(ep,d)
for i,b in enumerate(ep['beats']):b['i']=i
os.makedirs('/tmp/au',exist_ok=True)
audio.build(ep,vf,f'/tmp/{name}.wav','/tmp/au')
render.render(ep,f'/tmp/{name}_v.mp4','/home/claude/vid/es/avatar.png')
subprocess.run(['ffmpeg','-v','error','-y','-i',f'/tmp/{name}_v.mp4','-i',f'/tmp/{name}.wav','-c:v','libx264','-preset','slow','-b:v','560k','-maxrate','760k','-bufsize','1500k','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-shortest','-movflags','+faststart',f'/home/claude/v2/{name}.mp4'],check=True)
print(os.path.getsize(f'/home/claude/v2/{name}.mp4'),ep['dur'])
